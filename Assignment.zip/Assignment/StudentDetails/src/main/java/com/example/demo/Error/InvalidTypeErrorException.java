package com.example.demo.Error;

public class InvalidTypeErrorException extends RuntimeException{
	public InvalidTypeErrorException(String message) {
		super(message);
	}

}
